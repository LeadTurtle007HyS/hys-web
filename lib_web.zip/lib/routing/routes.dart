const OverViewPageRoute = "Overview";
const DriversPageRoute = "Drivers";
const ClientsPageRoute = "Clients";
const AuthenticationPageRoute = "Authentication";

List sideMenuItems = [
  OverViewPageRoute,
  DriversPageRoute,
  ClientsPageRoute,
  AuthenticationPageRoute
];
