import 'package:flutter/material.dart';

class RightSidebar extends StatefulWidget {
  const RightSidebar({Key? key}) : super(key: key);

  @override
  _RightSidebarState createState() => _RightSidebarState();
}

class _RightSidebarState extends State<RightSidebar> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
