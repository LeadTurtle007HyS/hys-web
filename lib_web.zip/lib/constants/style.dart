import 'package:flutter/material.dart';

Color background = const Color(0xFFFFFFFF);
Color light = const Color(0xFFF2F6F8);
Color lightGrey = const Color(0xFFA4A6B3);
Color dark = const Color(0xFF363740);
Color active = const Color(0xFF58A5C4);
