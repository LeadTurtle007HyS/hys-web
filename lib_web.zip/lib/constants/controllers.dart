import 'package:HyS/controllers/menu_controller.dart';
import 'package:HyS/controllers/navigation_controller.dart';

MenuController menuController = MenuController.instance;
NavigationController navigationController = NavigationController.instance;
