void configureApp() {
  // No-op.
}
