import 'package:HyS/pages/overView/widgets/overview_cards.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class OverViewCardsLargeScreen extends StatefulWidget {
  const OverViewCardsLargeScreen({Key? key}) : super(key: key);

  @override
  _OverViewCardsLargeScreenState createState() =>
      _OverViewCardsLargeScreenState();
}

class _OverViewCardsLargeScreenState extends State<OverViewCardsLargeScreen> {
  var ridesProgess = false.obs;
  var packageDelivered = false.obs;
  var canelledDelivery = false.obs;
  var scheduledDeliveries = false.obs;

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                  child: GestureDetector(
                      onTap: () {
                        ridesProgess.value = true;
                        packageDelivered.value = false;
                        canelledDelivery.value = false;
                        scheduledDeliveries.value = false;
                      },
                      child: Obx(
                        () => OverViewCard(
                            title: "Rides in progress",
                            value: "7",
                            color: Colors.orange,
                            isClicked: ridesProgess.value),
                      ))),
              Expanded(
                  child: GestureDetector(
                      onTap: () {
                        ridesProgess.value = false;
                        packageDelivered.value = true;
                        canelledDelivery.value = false;
                        scheduledDeliveries.value = false;
                      },
                      child: Obx(
                        () => OverViewCard(
                            title: "Packages deliverd",
                            value: "17",
                            color: Colors.green,
                            isClicked: packageDelivered.value),
                      ))),
              Expanded(
                  child: GestureDetector(
                      onTap: () {
                        ridesProgess.value = false;
                        packageDelivered.value = false;
                        canelledDelivery.value = true;
                        scheduledDeliveries.value = false;
                      },
                      child: Obx(
                        () => OverViewCard(
                            title: "Cancelled delivery",
                            value: "3",
                            color: Colors.redAccent,
                            isClicked: canelledDelivery.value),
                      ))),
              Expanded(
                  child: GestureDetector(
                      onTap: () {
                        ridesProgess.value = false;
                        packageDelivered.value = false;
                        canelledDelivery.value = false;
                        scheduledDeliveries.value = true;
                      },
                      child: Obx(
                        () => OverViewCard(
                            title: "Scheduled deliveries",
                            value: "7",
                            color: Colors.purple,
                            isClicked: scheduledDeliveries.value),
                      ))),
            ],
          ),
        ],
      ),
    );
  }
}
